package com.avaya.pso.web.springboot;

import java.util.Properties;

import org.slf4j.Logger;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.avaya.pso.web.springboot.service.EnvironmentConfigurationLogger;
import com.avaya.pso.web.springboot.service.ScreenpopApplicationProperties;


@SpringBootApplication
@Configuration
public class ScreenpopForSfrApplication extends SpringBootServletInitializer{

	@Bean
	ApplicationRunner applicationRunner(Environment environment) {
	 return args -> {
		ScreenpopApplicationProperties screenpopProperties = new ScreenpopApplicationProperties(); 
	    EnvironmentConfigurationLogger envLogger = new EnvironmentConfigurationLogger();
	    Logger LOGGER;
	    LOGGER = envLogger.getLogger();
		screenpopProperties.put("oneclick.secretkey", environment.getProperty("oneclick.secretkey"));
		screenpopProperties.put("oneclick.tokenexpirationdelay", environment.getProperty("oneclick.tokenexpirationdelay"));
		screenpopProperties.put("oneclick.url", environment.getProperty("oneclick.url"));
		
	    LOGGER.debug("oneclick.secretkey ----> " + environment.getProperty("oneclick.secretkey"));
	    LOGGER.debug("oneclick.tokenexpirationdelay ----> " + environment.getProperty("oneclick.tokenexpirationdelay"));
	    LOGGER.debug("oneclick.url ----> " + environment.getProperty("oneclick.url"));

	 };
	}
	
	private static void loadScreenpopApplicationProperties(ApplicationContext applicationContext)
	{
		ScreenpopApplicationProperties screenpopProperties = new ScreenpopApplicationProperties(); 
	    EnvironmentConfigurationLogger envLogger = new EnvironmentConfigurationLogger();
	    Logger LOGGER;
	    LOGGER = envLogger.getLogger();

		// Set screenpop applicaion properties 
		screenpopProperties.put("app.oneclicksecretkey", applicationContext.getEnvironment().getProperty("app.oneclicksecretkey"));
		screenpopProperties.put("app.oneclicktokenexpirationdelay", applicationContext.getEnvironment().getProperty("app.oneclicktokenexpirationdelay"));
		screenpopProperties.put("app.oneclickurl", applicationContext.getEnvironment().getProperty("app.oneclickurl"));
		
		LOGGER.debug("app.oneclicksecretkey = " + screenpopProperties.get("app.oneclicksecretkey"));
		LOGGER.debug("app.oneclicktokenexpirationdelay = " + screenpopProperties.get("app.oneclicktokenexpirationdelay"));
		LOGGER.debug("app.oneclickurl = " + screenpopProperties.get("app.oneclickurl"));
	}
	
	public static void main(String[] args) {
		SpringApplication.run(ScreenpopForSfrApplication.class, args);
	}

	private static void loadScreenpopApplicationProperties(Properties properties)
	{
		ScreenpopApplicationProperties screenpopProperties = new ScreenpopApplicationProperties(); 
	    EnvironmentConfigurationLogger envLogger = new EnvironmentConfigurationLogger();
	    Logger LOGGER;
	    LOGGER = envLogger.getLogger();

		// Set screenpop applicaion properties 
		screenpopProperties.put("app.oneclicksecretkey", properties.getProperty("app.oneclicksecretkey"));
		screenpopProperties.put("app.oneclicktokenexpirationdelay", properties.getProperty("app.oneclicktokenexpirationdelay"));
		screenpopProperties.put("app.oneclickurl", properties.getProperty("app.oneclickurl"));
		
		LOGGER.debug("app.oneclicksecretkey = " + screenpopProperties.get("app.oneclicksecretkey"));
		LOGGER.debug("app.oneclicktokenexpirationdelay = " + screenpopProperties.get("app.oneclicktokenexpirationdelay"));
		LOGGER.debug("app.oneclickurl = " + screenpopProperties.get("app.oneclickurl"));
	}
	
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder)
	{
		return builder.sources(ScreenpopForSfrApplication.class);
	}
		
	
}
