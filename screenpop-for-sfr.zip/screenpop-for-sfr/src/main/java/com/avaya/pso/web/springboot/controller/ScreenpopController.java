package com.avaya.pso.web.springboot.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ScreenpopController {

	@GetMapping({"/","/screenpop"})
	public String screenpop(@RequestParam(value = "uui", defaultValue ="",
	required = true) String name, Model model ) {
		model.addAttribute("name", name);
		return "screenpop";
	}
	
}
