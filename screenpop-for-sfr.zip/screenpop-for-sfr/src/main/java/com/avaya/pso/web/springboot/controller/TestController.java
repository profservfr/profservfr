package com.avaya.pso.web.springboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {
	
	@GetMapping({"/","/test"})
	public String testscreenpop(@RequestParam(value = "uui", defaultValue ="7c3132333435363738397c3030303030303030307c303132333435367c30303030303030303030;encoding=hex;purpose=isdn-interwork;content=isdn-uui",
	required = false) String uui, Model model ) {
		model.addAttribute("uui", uui);
		return "test";
	}
}
