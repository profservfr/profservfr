package com.avaya.pso.web.springboot.service;

import java.util.Properties;


public class ScreenpopApplicationProperties {

	public static Properties screenpopProperties;
	
	
	public ScreenpopApplicationProperties()
	{
		if (screenpopProperties == null)
			screenpopProperties = new Properties();
	}
	
	public void put(String propertyName, String propertyValue)
	{
		screenpopProperties.put(propertyName, propertyValue);
	}
	
	
    public String get (String propertyName) {
    	return screenpopProperties.getProperty(propertyName);
    }
}
