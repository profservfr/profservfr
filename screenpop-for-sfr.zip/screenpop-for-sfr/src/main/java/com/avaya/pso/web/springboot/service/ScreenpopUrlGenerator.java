
package com.avaya.pso.web.springboot.service;

import org.slf4j.Logger;

import com.avaya.pso.web.springboot.service.Uui.UuiData;

/**
 * This class is used for generating URL to redirect for screen pop
 *
 */
public class ScreenpopUrlGenerator {

	
	EnvironmentConfigurationLogger envLogger;
	Logger LOGGER;
	
	ScreenpopApplicationProperties screenpopProperties;

	private String _OneclickURLToRedirectRequest;
	
	public ScreenpopUrlGenerator()
	{
		screenpopProperties = new ScreenpopApplicationProperties();
		_OneclickURLToRedirectRequest = screenpopProperties.get("oneclick.url");
		
		envLogger = new EnvironmentConfigurationLogger();
        LOGGER = envLogger.getLogger();
	}
	
	public String getURL(String uui)
	{
		LOGGER.debug("UUI = " + uui);
		Uui myUui = new Uui(uui);
		UuiData data = myUui.getUuiData();
		if (data.isProperlyFormatted())
		{
			String token;
			TokenManager tokenManager = new TokenManager();
			token = tokenManager.getToken(data);
			_OneclickURLToRedirectRequest = _OneclickURLToRedirectRequest + token;
			LOGGER.debug("OneclickURLToRedirectRequest = " + _OneclickURLToRedirectRequest);
			return new String (_OneclickURLToRedirectRequest);
		}
		else
			return new String (_OneclickURLToRedirectRequest);
	}
	
	public String getTestURL()
	{
		LOGGER.debug("Testing UUI");
		Uui myUui = new Uui();
		UuiData data = myUui.getUuiData();
		if (data.isProperlyFormatted())
		{
			String token;
			TokenManager tokenManager = new TokenManager();
			token = tokenManager.getToken(data);
			return new String (_OneclickURLToRedirectRequest + token);
		}
		else
			return new String ("");
	}
	
}
