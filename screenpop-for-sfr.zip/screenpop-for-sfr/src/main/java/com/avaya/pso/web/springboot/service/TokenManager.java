package com.avaya.pso.web.springboot.service;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.xml.bind.*;

import jakarta.xml.bind.*;


import org.slf4j.Logger;

import com.avaya.pso.web.springboot.service.Uui.UuiData;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

//@Configuration
//@Configurable
//@Controller
//@PropertySource("classpath:application.properties")
public class TokenManager implements Serializable {

	
    // This class is in charge of the token 
    /*

    2.3.5 Token
    Token to exchange with OneClick :
    
    Token data are described below : 

    In the case of an empty UUI frame, which will therefore not trigger a file increase (PopUp), AVAYA can call ONE CLICK:
    - Either directly via the ONE CLICK url without Token,
    - Or with the Token generated only with the following informations : "Name of the calling application", "Creation timestamp" and "Expiration timestamp".
    The rest of the “NDI”, “Contract” and “Point of Sale Code” fields being empty because the UUI frame will be empty.


    Name	Type	Max length	Mandatory	Example	Comment
    app	    string	20	Y	avaya	Calling Application Name (fixed value)
    ndi	    string	9	N	23456789	NDI / msisdn (without any 0 on the left)
    ctr	    string	7	N	1234567	Contract ID (without any 0 on the left)
    pdv	    string	10	N	0000012345	Point Of Sale code (PDV)
    iat	    string	10	Y	1635514490	Creation Timestamp 
    exp	    string	10	Y	1635514520	Expiration Timestamp (IAT + 30 seconds)

    The token will be generated with the JWT Library (JSON WEB TOKEN : https://jwt.io/libraries)
    This token requires a signature so that the Token can be checked and validated by OneClick

    */

  
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	String _jsonString = "{\n" +
            "        \"app\":\"avaya               \",\n" +
            "        \"ndi\":\"23456789\",\n" +
            "        \"ctr\":\"$ctr$\",\n" +
            "        \"pdv\":\"$pdv$\",\n" +
            "        \"iat\":\"$iat$\",\n" +
            "        \"exp\":\"$exp$\",\n" + 
            "}";
	
    final String _QualifiedNumberSetToZeros = "000000000";
    final String _ContractNumberSetToZeros  = "0000000";

	
    private static long _expirationTimeInSecondes = 30;
	private static long JWT_TOKEN_VALIDITY = _expirationTimeInSecondes;
	private static final String _tokenSubject = ""; 
	
	private Map<String, String> _tokenClaims;
	
	private String sfrSecretKey;

    EnvironmentConfigurationLogger envLogger;
    Logger LOGGER;


    public TokenManager()
    {
    	super(); 

    	ScreenpopApplicationProperties screenpopProperties = new ScreenpopApplicationProperties();
    	
    	_tokenClaims = new HashMap<String, String>();
    	
        // Logger 
        envLogger = new EnvironmentConfigurationLogger();
        LOGGER = envLogger.getLogger();
        
        sfrSecretKey = screenpopProperties.get("oneclick.secretkey");
        LOGGER.debug("secret key = " + sfrSecretKey);
        
        _expirationTimeInSecondes = Long.parseLong(screenpopProperties.get("oneclick.tokenexpirationdelay"));
        LOGGER.debug("token expiration delay ..= " + Long.toString(_expirationTimeInSecondes));
        JWT_TOKEN_VALIDITY = _expirationTimeInSecondes;
        
    }

	//retrieve username from jwt token
	public String getUsernameFromToken(String token) {
		return getClaimFromToken(token, Claims::getSubject);
	}

	//retrieve expiration date from jwt token
	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}

	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}
    //for retrieveing any information from token we will need the secret key
	private Claims getAllClaimsFromToken(String token) {
		return Jwts.parser().setSigningKey(sfrSecretKey).parseClaimsJws(token).getBody();
	}

	// Could be used later
	//check if the token has expired
	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		return expiration.before(new Date());
	}


	//while creating the token -
	//1. Define  claims of the token, like Issuer, Expiration, Subject, and the ID
	//2. Sign the JWT using the HS256 algorithm and secret key.
	//3. According to JWS Compact Serialization(https://tools.ietf.org/html/draft-ietf-jose-json-web-signature-41#section-3.1)
	//   compaction of the JWT to a URL-safe string 
	private String doGenerateToken(Map<String, Object> claims, String subject) {
//		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
		return Jwts.builder().setClaims(claims).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + JWT_TOKEN_VALIDITY * 1000))
//				.signWith(SignatureAlgorithm.HS512, sfrSecretKey).compact();
				.signWith(SignatureAlgorithm.HS256, sfrSecretKey).compact();
	}

		
	// One Click oriented methods
	private long getCurrentTimeIn10DigitsTimeStamp()
	{
		 Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		 return (long) currentTime.getTime() / 1000;
	}
	
	
	private void logClaimsOfToken()
	{
		if (LOGGER.isDebugEnabled())
		{
			LOGGER.debug("Claim's token in order ...");
			for (int i=0; i < _tokenClaims.size(); i++)
			{
				String key = (String) _tokenClaims.keySet().toArray()[i];
				String valueOfKey = (String) _tokenClaims.get(key);
				LOGGER.debug(key + " = " + valueOfKey);
			}
		}
		
	}
	
	private void prepareClaimsOfToken(UuiData fromUui)
	{
		long currentTime = getCurrentTimeIn10DigitsTimeStamp();
		long expirtationTime = currentTime + _expirationTimeInSecondes;
		_tokenClaims.put("app", new String ("avaya"));
		_tokenClaims.put("ndi", new String (fromUui.callingNumber));
		_tokenClaims.put("ctr", new String (fromUui.contractNumber));
		_tokenClaims.put("pdv", new String (fromUui.pointOfSaleCode));
		_tokenClaims.put("iat", new String (Long.toString(currentTime)));
		_tokenClaims.put("exp", new String (Long.toString(expirtationTime)));	
		
		logClaimsOfToken();
	}
	
	
	public String getToken(UuiData fromUui)
	{
		String generatedToken;
		prepareClaimsOfToken(fromUui);
    	Map<String,Object> tokenClaimsInObject = new HashMap<String,Object>();
    	
    	tokenClaimsInObject.put("app", _tokenClaims.get("app"));

    	if (_tokenClaims.get("ndi") != _QualifiedNumberSetToZeros)
    		tokenClaimsInObject.put("ndi", _tokenClaims.get("ndi"));
    	
	    if (_tokenClaims.get("ctr") != _ContractNumberSetToZeros)
	    	tokenClaimsInObject.put("ctr", _tokenClaims.get("ctr"));

	    tokenClaimsInObject.put("pdv", _tokenClaims.get("pdv"));
    	tokenClaimsInObject.put("iat", _tokenClaims.get("iat"));
    	tokenClaimsInObject.put("exp", _tokenClaims.get("exp"));
    	
    	generatedToken = doGenerateToken(tokenClaimsInObject, _tokenSubject);
    	LOGGER.debug("JWT Token = " + generatedToken);
    	
		return generatedToken;
	}

	
}