package com.avaya.pso.web.springboot.service;

import org.slf4j.Logger;

//@Component
public class Uui 
{
    // 2.2 Contract number
    // The length of the « contract number » is from 3 to 6 digits.in order to simplify the debugging and the limitation of the UUI frame, this information will be supplemented, by the IVR, with “0” up to 7 digits.

    // 2.3 Example of frames received by AVAYA

    /* 

    Case 1: Entry of the contract and no entry of NDI or no test on the calling number in the IVR NEOGU:
    - Calling number = 123456789
    - Qualified number = 00000000 (set by the IVR)
    - Contract = 0123456
    - PDV code = 0000000000
    
    Avaya sends to One Click only the Contract number without the extra “0” on the left only (in case there is a 0 inside the contract number, this 0 should not be removed) (Avaya will only consider the fields with data, excluding the one with calling number)  “123456”.
    Example of frame received by AVAYA:
    	TRAME ASCII : « |123456789|000000000|0123456|0000000000;encoding=hex;purpose=isdn-interwork;content=isdn-uui »
    	TRAME HEX : « 7c3132333435363738397c3030303030303030307c303132333435367c30303030303030303030;encoding=hex;purpose=isdn-interwork;content=isdn-uui »

    Case 2: Entering the contract and entering its number in the IVR NEOGU:
    - Calling number = 123456789
    - Qualified Number = 612345678
    - Contract = 0123456
    - PDV code = 0000000000

    Some errors can prevent the call from going through the GENESYS IVR. In this case, the UUI frame received by AVAYA will be empty.
    */


	
    EnvironmentConfigurationLogger envLogger;
    Logger LOGGER;

    public class UuiData {
        String callingNumber;      // 9 digits  information not used for raising the file but transmitted to the AVAYA banner for debugging / analysis of call behavior.
        String qualifiedNumber;
        String contractNumber;      // on 7 digits (completed with "0" by the IVR) for debugging and frame limit.
        String pointOfSaleCode;     // 10 digits (completed with "0" by the IVR).
        private boolean properlyFormatted;  // indicates if data received respected formatting as described before.
        
        public UuiData()
        {
        	setProperlyFormatted(false);
        }
		public boolean isProperlyFormatted() {
			return properlyFormatted;
		}
		public void setProperlyFormatted(boolean properlyFormatted) {
			this.properlyFormatted = properlyFormatted;
		}
    }

    String _uuiInHEX;
    String _uuiInASCII;

    final int _UuiLengthInHEX = 78;
    final int _UuiLengthInASCII = -1;       // We will see

    final char _BeginningOfUselessData = ';';

    final String _QualifiedNumberSetToZeros = "000000000";
    final String _ContractNumberSetToZeros  = "0000000";
    final int _ContractNumberLength  = _ContractNumberSetToZeros.length();
    
    
    final int _CallingNumberLength = 9;
    final int _QualifiedNumberLength = 9;
    final int _PDVCodeLength = 10;



    public Uui()
    {
    	
        // This is used for testing only. Copy constructor must be used in normal situation. 
        _uuiInHEX =  new String("7c3132333435363738397c3030303030303030307c303132333435367c30303030303030303030;encoding=hex;purpose=isdn-interwork;content=isdn-uui");
        _uuiInASCII = new String ("|123456789|000000000|0123456|0000000000;encoding=hex;purpose=isdn-interwork;content=isdn-uui");
        
        envLogger = new EnvironmentConfigurationLogger();
        LOGGER = envLogger.getLogger();
    }

    public Uui(String uuiField)
    {
        envLogger = new EnvironmentConfigurationLogger();
        LOGGER = envLogger.getLogger();


        int position = findInStr(uuiField, _BeginningOfUselessData);
        _uuiInHEX = new String(uuiField.substring(0, position));

        if (!hasValidData(_uuiInHEX))
        {
            LOGGER.error("Invalid UUI field = " + uuiField);
        }

        // Convert to ASCII
        _uuiInASCII = ConvertToASCII(_uuiInHEX);

        LOGGER.debug("UUI in HEX = " + _uuiInHEX);
        LOGGER.debug("UUI in ASCII = " + _uuiInASCII);
    }

    private void logUuiData(UuiData uuiDataToLog)
    {
        if (LOGGER.isDebugEnabled())
        {
            LOGGER.debug("callingNumber = " + uuiDataToLog.callingNumber);
            LOGGER.debug("qualifiedNumber = " + uuiDataToLog.qualifiedNumber);
            LOGGER.debug("contractNumber = " + uuiDataToLog.contractNumber);
            LOGGER.debug("pointOfSaleCode = " + uuiDataToLog.pointOfSaleCode);
        }
    }

    public UuiData getUuiData()
    {
        UuiData tData = new UuiData();
    	if (!_uuiInASCII.isEmpty())
    	{
	        tData.callingNumber = getCallingNumber(_uuiInASCII);
	        tData.contractNumber = getContractNumber(_uuiInASCII);
	        tData.pointOfSaleCode = getPDVCode(_uuiInASCII);
	        tData.qualifiedNumber = getQualifiedNumber(_uuiInASCII);
	        tData.setProperlyFormatted(true);
	        logUuiData(tData);
    	}
    	else
    	{
            LOGGER.error("UUI in ASCII is empty.");
	        tData.setProperlyFormatted(false);    		
    	}
        return tData;
    }

    private boolean hasValidData(String uuiInHEX)
    {
        
        if (uuiInHEX.isEmpty() || uuiInHEX.isBlank())
        {
            LOGGER.error("UUI field is empty");
            return false;
        }
        if (uuiInHEX.length() %2 != 0)
        {
            LOGGER.error("UUI does not contain a pair number of characters.");
            LOGGER.error("Actual UUI length = " + Integer.toString(uuiInHEX.length()));
            return false;
        }
            
        if (uuiInHEX.length() == _UuiLengthInHEX)
            return true;
        else 
        {
            LOGGER.error("UUI length is not equal = " + Integer.toString(_UuiLengthInHEX));
            LOGGER.error("Actual UUI length = " + Integer.toString(uuiInHEX.length()));
            return false;
        }
    }

    
    public static int findInStr(String s1, char c)
    {
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i) == c) 
                return i;
        }
        return -1;
    }

    private String ConvertToASCII(String UuiInHEX)
    {
        int i=0;
         
        StringBuilder builder = new StringBuilder();
        while (i < UuiInHEX.length())
        {
            // Step-1 Split the hex string into two character group
            String convertedValue = UuiInHEX.substring(i, i + 2);
             // Step-2 Convert the each character group into integer using valueOf method
            int n = Integer.valueOf(convertedValue, 16);
            // Step-3 Cast the integer value to char
            builder.append((char)n);   

            i += 2;
        }
        return builder.toString();
    }

    private String getContractNumber(String UuiInASCII)
    {
        // |123456789|000000000|0000000|0001021477
        // extract 0001021477
    	String contractNumber = new String(UuiInASCII.substring(21, 21 + _ContractNumberLength));
        LOGGER.debug("contractNumber = " + contractNumber);
        return  contractNumber;
    }

    private String getQualifiedNumber (String UuiInASCII)
    {
        // |123456789|987654321|0000000|0001021477
        // extract 987654321
    	String qualifiedNumber = new String(UuiInASCII.substring(11, 11 + _QualifiedNumberLength));
        LOGGER.debug("qualifiedNumber = " + qualifiedNumber);
        return qualifiedNumber;
    }

    private String getCallingNumber(String UuiInASCII)
    {
        // |123456789|000000000|0000000|0001021477
        // extract 123456789
    	String callingNumber = new String(UuiInASCII.substring(1, 1 + _CallingNumberLength));
        LOGGER.debug("callingNumber = " + callingNumber);
        return callingNumber;
    }   

    private String getPDVCode (String UuiInASCII)
    {
        // |123456789|000000000|0000000|0001021477
        // extract 0001021477
    	String PDVCode = new String(UuiInASCII.substring(29, 29 + _PDVCodeLength));
        LOGGER.debug("PDVCode = " + PDVCode);
        return PDVCode;
    }   

}
