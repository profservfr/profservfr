package com.avaya.pso.web.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenpopForSfrApplicationTests {

	@Test
	void contextLoads() {
	}

}
